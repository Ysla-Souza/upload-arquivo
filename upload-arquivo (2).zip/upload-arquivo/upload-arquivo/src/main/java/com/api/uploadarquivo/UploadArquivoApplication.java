package com.api.uploadarquivo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UploadArquivoApplication {

	public static void main(String[] args) {
		SpringApplication.run(UploadArquivoApplication.class, args);
	}

}
