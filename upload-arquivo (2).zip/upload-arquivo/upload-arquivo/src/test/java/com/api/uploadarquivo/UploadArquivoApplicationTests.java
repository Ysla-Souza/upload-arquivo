package com.api.uploadarquivo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UploadArquivoApplicationTests {

	@Test
	void contextLoads() {
	}

}
